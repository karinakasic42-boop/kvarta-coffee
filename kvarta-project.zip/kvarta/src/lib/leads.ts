import { promises as fs } from 'node:fs';
import path from 'node:path';

export type Lead = {
  id: string; name: string; phone: string; interest: 'subscription' | 'one-time' | 'question';
  comment: string; source: string; medium: string; campaign: string; content: string; term: string;
  landingPage: string; referrer: string; createdAt: string;
};
const key = (phone: string) => `lead:phone:${phone}`;
const redisReady = () => Boolean(process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN);

export async function findRecentLead(phone: string): Promise<boolean> {
  if (redisReady()) {
    const { Redis } = await import('@upstash/redis');
    const redis = Redis.fromEnv();
    return Boolean(await redis.get(key(phone)));
  }
  // Local fallback is only for development. Vercel's filesystem is ephemeral; configure Upstash for production.
  try {
    const records = JSON.parse(await fs.readFile(path.join(process.cwd(), '.leads.json'), 'utf8')) as Lead[];
    const cutoff = Date.now() - 10 * 60 * 1000;
    return records.some((lead) => lead.phone === phone && new Date(lead.createdAt).getTime() > cutoff);
  } catch { return false; }
}
export async function saveLead(lead: Lead): Promise<void> {
  if (redisReady()) {
    const { Redis } = await import('@upstash/redis');
    const redis = Redis.fromEnv();
    // Atomic lock prevents simultaneous duplicate submissions from racing each other.
    const result = await redis.set(key(lead.phone), lead.id, { nx: true, ex: 600 });
    if (result !== 'OK') throw new Error('DUPLICATE_LEAD');
    try { await redis.lpush('leads:all', JSON.stringify(lead)); }
    catch (error) { await redis.del(key(lead.phone)); throw error; }
    return;
  }
  const file = path.join(process.cwd(), '.leads.json');
  let records: Lead[] = [];
  try { records = JSON.parse(await fs.readFile(file, 'utf8')) as Lead[]; } catch { /* first local submission */ }
  const cutoff = Date.now() - 10 * 60 * 1000;
  if (records.some((item) => item.phone === lead.phone && new Date(item.createdAt).getTime() > cutoff)) throw new Error('DUPLICATE_LEAD');
  records.push(lead);
  await fs.writeFile(file, JSON.stringify(records, null, 2), { encoding: 'utf8', mode: 0o600 });
}

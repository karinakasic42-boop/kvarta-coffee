import type { Metadata, Viewport } from 'next';
import './globals.css';
export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://kvarta-coffee.vercel.app'),
  title: 'Кварта — кофе, который успевает быть свежим',
  description: 'Небольшая обжарка в Минске. Обжариваем по четвергам, привозим по пятницам. Кофе для вашего утра — без лишних слов.',
  openGraph: { title: 'Кварта — кофе, который успевает быть свежим', description: 'Обжариваем по четвергам. Привозим по пятницам.', type: 'website', images: ['/og-coffee.svg'] },
  twitter: { card: 'summary_large_image', title: 'Кварта — кофе, который успевает быть свежим', description: 'Обжариваем по четвергам. Привозим по пятницам.', images: ['/og-coffee.svg'] },
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#f4f0e7' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="ru"><body>{children}</body></html>; }

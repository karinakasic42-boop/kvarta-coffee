import { NextRequest, NextResponse } from 'next/server';
import { findRecentLead, saveLead, type Lead } from '@/lib/leads';
export const runtime = 'nodejs';
const phonePattern = /^(?:\+375|375|80)\s?\(?\d{2}\)?[\s-]?\d{3}[\s-]?\d{2}[\s-]?\d{2}$/;
const clean = (value: unknown, max: number) => typeof value === 'string' ? value.trim().slice(0, max) : '';
export async function POST(request: NextRequest) {
  let body: Record<string, unknown>;
  try { body = await request.json() as Record<string, unknown>; }
  catch { return NextResponse.json({ error: 'Не удалось прочитать форму. Обновите страницу и попробуйте ещё раз.' }, { status: 400 }); }
  const name = clean(body.name, 80);
  const rawPhone = clean(body.phone, 40);
  const phone = rawPhone.replace(/[\s()-]/g, '').replace(/^80/, '+375').replace(/^375/, '+375');
  const interest = clean(body.interest, 30);
  const comment = clean(body.comment, 1000);
  if (name.length < 2) return NextResponse.json({ error: 'Напишите, пожалуйста, как к вам обращаться.' }, { status: 400 });
  if (!phonePattern.test(rawPhone) || !/^\+375\d{9}$/.test(phone)) return NextResponse.json({ error: 'Проверьте номер: нужен белорусский номер, например +375 29 123-45-67.' }, { status: 400 });
  if (!['subscription', 'one-time', 'question'].includes(interest)) return NextResponse.json({ error: 'Выберите, что вас интересует.' }, { status: 400 });
  try {
    if (await findRecentLead(phone)) return NextResponse.json({ error: 'Заявка с этим номером уже отправлена. Мы скоро свяжемся с вами.' }, { status: 409 });
    const lead: Lead = {
      id: crypto.randomUUID(), name, phone, interest: interest as Lead['interest'], comment,
      source: clean(body.source, 200), medium: clean(body.medium, 200), campaign: clean(body.campaign, 200),
      content: clean(body.content, 200), term: clean(body.term, 200), landingPage: clean(body.landingPage, 500),
      referrer: clean(body.referrer, 500), createdAt: new Date().toISOString(),
    };
    await saveLead(lead);
    if (process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID) {
      const message = `☕ Новая заявка «Кварта»\nИмя: ${lead.name}\nТелефон: ${lead.phone}\nИнтерес: ${{ subscription: 'Подписка', 'one-time': 'Разовый заказ', question: 'Вопрос' }[lead.interest]}\nКомментарий: ${lead.comment || '—'}\nИсточник: ${lead.source || 'не указан'} / ${lead.medium || '—'}\nКампания: ${lead.campaign || '—'}\nОбъявление: ${lead.content || '—'}\nСтраница: ${lead.landingPage || '—'}`;
      try { await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: process.env.TELEGRAM_CHAT_ID, text: message }), signal: AbortSignal.timeout(3000) }); } catch { /* lead is already saved; notification failure must not lose it */ }
    }
    return NextResponse.json({ ok: true, message: 'Спасибо! Заявка принята. Скоро с вами свяжемся.' }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message === 'DUPLICATE_LEAD') return NextResponse.json({ error: 'Заявка с этим номером уже отправлена. Мы скоро свяжемся с вами.' }, { status: 409 });
    return NextResponse.json({ error: 'Не получилось отправить заявку. Попробуйте ещё раз чуть позже или позвоните нам.' }, { status: 500 });
  }
}
